using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMaster : MonoBehaviour
{
    [SerializeField] private float force = 1, torque = 20; // Variables for Downforce and Rotation
    [SerializeField] private int hitsToKill = 1; // Amount of hits before enemy is destroyed
    [SerializeField] private int points = 1; // Amount of points enemy will give you when you destroy it
    private float yDestroyBoundaryUpper = 7.5f; //|
    private int yDestroyBoundaryLower = -5;     //| Boundaries for when enemy is offscreen to destroy it
    private float xDestroyBoundary = 10.3f;     //|
    private Rigidbody enemyRB;  // Container for Rigidbody
    [SerializeField] private GameObject bullet;
    // Start is called before the first frame update
    void Start()
    {
        string tagName = gameObject.tag;
        switch (tagName)
        {
            case "shooter": // If the enemy is a shooter then do whats in here
                StartCoroutine(FireBullets()); 
                break;
            case "randommover": // If the enemy is a Random Mover then do whats in here
                InvokeRepeating("RandomMove", 2, 2); 
                break;
        }

        enemyRB = GetComponent<Rigidbody>(); // Retrieve the actual rigidBody from the Object
        MoveEnemy(); // Call the function to move the object
    }

    // Update is called once per frame
    void Update()
    {
        // Destroy enemy if reaches destroyBoundary
        if (transform.position.y < yDestroyBoundaryLower || transform.position.y > yDestroyBoundaryUpper || transform.position.x < -xDestroyBoundary || transform.position.x > xDestroyBoundary)
        {
            Destroy(gameObject);
        }
        //----------------------------------------- 
    }
    private void MoveEnemy() // Move the Enemy using variables force and torque
    {
        enemyRB.AddForce(Vector3.down * force, ForceMode.Impulse); // Push it down
        enemyRB.AddTorque(new Vector3(torque, torque, torque)); // Rotate it
    }

    IEnumerator FireBullets() // Anywhere between 1 and 3 Seconds the enemy will fire a bullet
    {
        while (true)
        {
            yield return new WaitForSeconds(Random.Range(1, 4));
            Instantiate(bullet, transform.position, bullet.transform.rotation);

        }
    }
    private void RandomMove()
    {
        int states = Random.Range(0, 4); // Pick a random number between Zero and 3
        switch (states) // Depending on the number, run one of these cases to change direction
        {
            case 0:
                enemyRB.AddForce(Vector3.down * force, ForceMode.Impulse); // Push it down
                break;
            case 1:
                enemyRB.AddForce(Vector3.up * force, ForceMode.Impulse); // Push it up
                break;
            case 2:
                enemyRB.AddForce(Vector3.left * force, ForceMode.Impulse); // Push it left
                break;
            case 3:
                enemyRB.AddForce(Vector3.right * force, ForceMode.Impulse); // Push it right
                break;
        }
    }
}
