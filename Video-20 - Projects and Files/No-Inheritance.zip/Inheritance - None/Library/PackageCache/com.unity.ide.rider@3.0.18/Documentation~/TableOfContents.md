* [About JetBrains Rider Editor](index.md)
* [Using the JetBrains Rider Editor package](using-the-jetbrains-rider-editor-package.md)