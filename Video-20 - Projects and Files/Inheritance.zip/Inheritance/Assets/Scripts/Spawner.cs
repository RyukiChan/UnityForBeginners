using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    private float ySpawn = 7.2f; // Spawn at top of the screen
    private float xSpawnBoundary = 9.5f; // Boundary not to spawn past on the x Axis
    public GameObject[] enemies; // Array of enemies to Spawn
    [SerializeField] private float spawnRate = 1; // Rate to spawn enemies in

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnStuff", 1, spawnRate); // Call the function 1 second after the scene loads and then repeat at the rate set by spawnRate
    }

    private void SpawnStuff() // Start spawning random enmemies in
    {
        float xPOS = Random.Range(-xSpawnBoundary, xSpawnBoundary); // Local variable to hold the xPOS position
        int index = Random.Range(0, enemies.Length); // Local variable to hold the index of which enemy to spawn
        Instantiate(enemies[index], new Vector3(xPOS, ySpawn), transform.rotation);
    }
}
