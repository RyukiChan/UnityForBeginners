using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooter : EnemyMaster
{
    public GameObject bullet;

    protected override void Start()
    {
        base.Start();
        StartCoroutine(FireBullets()); // Run this script code just for this enemy
    }
    IEnumerator FireBullets() // Anywhere between 1 and 3 Seconds the enemy will fire a bullet
    {
        while (true)
        {
            yield return new WaitForSeconds(Random.Range(1, 4));
            Instantiate(bullet, transform.position, bullet.transform.rotation);

        }
    }
    public override void DownForce() { } // Don't wan't to change it but must specify the override anyway (Because we are forced to by Abstract)
}
