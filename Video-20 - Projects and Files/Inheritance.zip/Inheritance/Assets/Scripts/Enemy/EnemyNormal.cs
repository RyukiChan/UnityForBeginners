using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyNormal : EnemyMaster
{
    public override void DownForce() { } // Don't wan't to change it but must specify the override anyway (Because we are forced to by Abstract)
}
