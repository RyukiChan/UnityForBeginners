using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class EnemyMaster : MonoBehaviour
{
    [SerializeField] protected float force = 1, torque = 20; // Variables for Downforce and Rotation
    [SerializeField] protected int hitsToKill = 1; // Amount of hits before enemy is destroyed
    [SerializeField] protected int points = 1; // Amount of points enemy will give you when you destroy it

    private float yDestroyBoundaryUpper = 7.5f; //|
    private int yDestroyBoundaryLower = -5;     //| Boundaries for when enemy is offscreen to destroy it
    private float xDestroyBoundary = 10.3f;     //|

    protected Rigidbody enemyRB;  // Container for Rigidbody


    protected virtual void Start()
    {
        DownForce();
        enemyRB = GetComponent<Rigidbody>(); // Retrieve the actual rigidBody from the Object
        MoveEnemy(); // Call the function to move the object
    }


    void Update()
    {
        // Destroy enemy if reaches destroyBoundary
        if (transform.position.y < yDestroyBoundaryLower || transform.position.y > yDestroyBoundaryUpper || transform.position.x < -xDestroyBoundary || transform.position.x > xDestroyBoundary)
        {
            Destroy(gameObject);
        }
        //----------------------------------------- 
    }
    public virtual void MoveEnemy() // Move the Enemy using variables force and torque
    {
        enemyRB.AddForce(Vector3.down * force, ForceMode.Impulse); // Push it down
        enemyRB.AddTorque(new Vector3(torque, torque, torque)); // Rotate it
    }
    public abstract void DownForce();
}
