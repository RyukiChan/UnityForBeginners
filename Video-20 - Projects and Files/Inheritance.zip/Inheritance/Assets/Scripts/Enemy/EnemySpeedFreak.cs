using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpeedFreak : EnemyMaster
{
    public override void DownForce() // Override force value to more than EnemyMaster. Change to 1.5
    {
        force = 1.5f;
    }
}
