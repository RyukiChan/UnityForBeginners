using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyRandomMover : EnemyMaster
{
    public override void MoveEnemy()
    {
        base.MoveEnemy(); // Run the base(Parent Class) movement from EnemyMaster
        InvokeRepeating("RandomMove", 2, 2); // Start random Movement in THIS script after 2 Seconds
    }
        private void RandomMove()
    {
        int states = Random.Range(0, 4); // Pick a random number between Zero and 3
        switch (states) // Depending on the number, run one of these cases to change direction
        {
            case 0:
                enemyRB.AddForce(Vector3.down * force, ForceMode.Impulse); // Push it down
                break;
            case 1:
                enemyRB.AddForce(Vector3.up * force, ForceMode.Impulse); // Push it up
                break;
            case 2:
                enemyRB.AddForce(Vector3.left * force, ForceMode.Impulse); // Push it left
                break;
            case 3:
                enemyRB.AddForce(Vector3.right * force, ForceMode.Impulse); // Push it right
                break;
        }
    }
    public override void DownForce() { } // Don't wan't to change it but must specify the override anyway (Because we are forced to by Abstract)
}
