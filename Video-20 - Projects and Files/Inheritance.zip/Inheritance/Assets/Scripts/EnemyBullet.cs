using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    [SerializeField] private float speed = 2; // Speed variable for bullet speed
    private int destroyBoundary = -5; // Boundary for when bullet is offscreen to destroy it

    void Update()
    {
        transform.Translate(Vector3.down * speed * Time.deltaTime);

        // Destroy bullet if reaches destroyBoundary
        if (transform.position.y < destroyBoundary)
        {
            Destroy(gameObject);
        }
        //----------------------------------------- 
    }
}
